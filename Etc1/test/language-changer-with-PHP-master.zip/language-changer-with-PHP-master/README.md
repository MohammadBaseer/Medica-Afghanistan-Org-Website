How to create a language changer with PHP
=============

These files acompany the tutorial: [How to create a language changer with PHP](http://daveismyname.com/how-to-create-a-language-changer-with-php-bp)