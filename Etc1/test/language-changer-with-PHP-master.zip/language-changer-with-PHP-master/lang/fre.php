<?php
//french lang

//nav
$lang['lang-eng'] = 'Anglais';
$lang['lang-fre'] = 'Franz�sisch';
$lang['lang-ger'] = 'Allemand';

//index 
$lang['index-title'] = 'D�mo de langue';
$lang['index-welcome'] = 'Bienvenue � la d�mo de langue';
$lang['index-text-1'] = "Lorem Ipsum est le texte simplement factice de l'industrie d'impression et de composition. Lorem Ipsum a �t� l'industry' ; texte factice standard de s depuis les 1500s, quand un imprimeur inconnu a pris un office de type et l'a brouill� pour faire un type livre de sp�cimen. Il a surv�cu non seulement � cinq si�cles, mais �galement au saut dans la composition �lectronique, demeurant essentiellement sans changement. Il a �t� popularis� dans les ann�es 60 avec le d�gagement des feuilles de Letraset contenant des passages de Lorem Ipsum, et plus r�cemment avec le logiciel de publication assist�e par ordinateur comme Aldus PageMaker comprenant des versions de Lorem Ipsum.";
$lang['demo'] = 'Revenez au cours d\'instruction';
?>