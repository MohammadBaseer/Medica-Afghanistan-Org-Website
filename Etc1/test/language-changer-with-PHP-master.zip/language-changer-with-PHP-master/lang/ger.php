<?php
//german lang

//nav
$lang['lang-eng'] = 'Englisch';
$lang['lang-fre'] = 'Franz�sisch';
$lang['lang-ger'] = 'Deutsch';

//index 
$lang['index-title'] = 'Sprachdemo';
$lang['index-welcome'] = 'Willkommen zur Sprachdemo';
$lang['index-text-1'] = "Lorem Ipsum ist einfach blinder Text der Drucken- und Schriftsetzenindustrie. Lorem Ipsum ist das industry' gewesen; s-blinder Standardtext seit die 1500s, als ein unbekannter Drucker eine Galeere der Art nahm und sie kroch, um eine Art Exemplarbuch zu bilden. Er hat nicht nur f�nf Jahrhunderte, aber auch den Sprung in das elektronische Schriftsetzen �berlebt und im Wesentlichen unver�ndert geblieben. Er wurde in den sechziger Jahren mit der Freisetzung von den Letraset Bl�ttern popularisiert, die vor kurzem Lorem Ipsum Durchg�nge enthalten, und mit Desktoppublishingsoftware wie Aldus PageMaker einschlie�lich Versionen von Lorem Ipsum.";
$lang['demo'] = 'Gehen Sie zum Tutorium zur�ck';
?>